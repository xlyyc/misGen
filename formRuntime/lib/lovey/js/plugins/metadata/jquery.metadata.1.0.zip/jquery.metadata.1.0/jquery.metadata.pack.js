/*
 * Metadata - jQuery plugin for parsing metadata from elements
 *
 * Copyright (c) 2006 John Resig, Yehuda Katz, J�rn Zaefferer
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 *
 * Revision: $Id: metadata.js 3553 2007-10-04 20:34:19Z joern.zaefferer $
 *
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(6($){$.4={g:"o",f:"j",t:6(a,b){2.g=a;2.f=b},n:/({.*})/,7:\'j\'};5 d=$.h.q;$.h.q=6(c){8 d.E(2,C).z(6(){3(2.l||2.v==9||$.u(2))8;5 a="{}";3($.4.g=="o"){5 m=$.4.n.s(2.r);3(m)a=m[1]}i 3($.4.g=="J"){3(!2.p)8;5 e=2.p($.4.f);3(e.I)a=$.H(e[0].D)}i 3(2.k!=B){5 b=2.k($.4.f);3(b)a=b}3(a.A(\'{\')<0)a="{"+a+"}";a=F("("+a+")");3($.4.7)2[$.4.7]=a;i $.G(2,a);2.l=y})};$.h.x=6(){8 2[0][$.4.7]}})(w);',46,46,'||this|if|meta|var|function|single|return|||||||name|type|fn|else|metadata|getAttribute|metaDone||cre|class|getElementsByTagName|setArray|className|exec|setType|isXMLDoc|nodeType|jQuery|data|true|each|indexOf|undefined|arguments|innerHTML|apply|eval|extend|trim|length|elem'.split('|'),0,{}))