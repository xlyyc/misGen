/**
 * 扩展插件定义
 */
(function ($) {
    pluginloader = {
        defPlugins:''
    }
})(jQuery);